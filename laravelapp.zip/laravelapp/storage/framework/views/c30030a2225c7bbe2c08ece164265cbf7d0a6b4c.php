<?php $__env->startSection('main'); ?>
    <div id="about">
        <h2>About</h2>
        <p>Aplikasi <strong>laravelapp</strong>
        dibuat sebagai latihan untuk mempelajari Laravel.</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>