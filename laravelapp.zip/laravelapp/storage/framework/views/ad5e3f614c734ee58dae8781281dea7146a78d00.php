<div id="pencarian">
    <?php echo Form::open(['url' => 'siswa/cari', 'method' => 'GET']); ?>

        <div class="input-group">
        <?php echo Form:: text('kata_kunci', (! empty($kata_kunci)) ? $kata_kunci : null,['class' => 'form-control', 'placeholder' => 'Masukkan Nama Siswa']); ?>

        <span class="input-group-btn">
        <?php echo Form::button('Cari', ['class' => 'btn btn-default', 'type' => 'submit']); ?>

        </span>
        </div>
    <?php echo Form::close(); ?>

</div>

<style>
#pencarian {
    border-bottom: 1px solid #000;
    padding-bottom: 10px;
}
</style>