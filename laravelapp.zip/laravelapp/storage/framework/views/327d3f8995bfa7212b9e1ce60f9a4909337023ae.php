<?php $__env->startSection('main'); ?>
    <div id="hobi">
        <h2>Edit Hobi</h2>

        <?php echo Form::model($hobi, ['method' => 'PATCH', 'action' => ['HobiController@update', $hobi->id]]); ?>

            <?php echo $__env->make('hobi.form', ['submitButtonText' => 'Update Hobi'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>