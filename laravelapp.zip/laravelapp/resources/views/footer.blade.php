<div id="footer">
    <p>&copy; 2016 laravelapp.dev</p>
</div>